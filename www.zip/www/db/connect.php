<?php

$driver = 'mysql';
$host = 'localhost';
$db_name = 'library';
$db_user = 'root';
$db_pass = 'mysql';
$charset = 'utf8';
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];

try{
    $pdo = new PDO (
        $dsn = "$driver: host=$host;dbname=$db_name;charset=$charset", $db_user, $db_pass, $options
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch (PDOException $i) {
    die("Ошибка подключения к базе данных");
}