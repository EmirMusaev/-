<?php //pdo

require 'connect.php';
/* 
function tt($value){
    echo '<pre>';
    print_r($value);
    echo '</pre>';
  };
      //порверка выполнения запроса к бд
function dbCheckError($query){
    $errInfo = $query->errorInfo();
    if ($errInfo[0] !== PDO::ERR_NONE){
        echo $errInfo[2];
        exit();
    }
    return true;
  }

 */


// tt($sql);
// exit();
/* 
$query = $pdo->prepare($sql);
$query->execute($param);


dbCheckError($query); */
