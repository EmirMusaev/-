<?php
$host = 'localhost';
$data = 'library';
$user = 'root';
$pass = 'mysql';

?>