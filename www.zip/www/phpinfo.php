<?php
	

	echo phpinfo();

	
	
?>


